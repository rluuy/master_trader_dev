import boto3
import json
import random
import datetime


def lambda_handler(event, context):
    """
    Lambda function to generate stock recommendations and quips for a specified trader.
    """
    # Get trader ID from the event
    trader_id = None

    # Handle both API Gateway and direct invocation formats
    if event.get('pathParameters') and 'traderId' in event['pathParameters']:
        trader_id = event['pathParameters']['traderId']
    elif 'traderId' in event:
        trader_id = event['traderId']

    if not trader_id:
        return {
            'statusCode': 400,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': 'Missing traderId parameter'})
        }

    # Fetch trader profile from DynamoDB
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('trader-profiles')

    try:
        response = table.get_item(Key={'TraderId': trader_id})
        trader = response.get('Item')

        if not trader:
            return {
                'statusCode': 404,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'error': f'Trader profile not found for ID {trader_id}'})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': f'Database error: {str(e)}'})
        }

    # Generate stock recommendations based on trader's strategy
    recommendations = get_recommendations_for_trader(trader)

    # Generate a personalized quip for the top recommendation
    top_recommendation = recommendations[0]
    quip = generate_quip(trader, top_recommendation['ticker'])

    # Prepare the response
    result = {
        'traderId': trader_id,
        'traderName': trader_id,
        'traderDescription': trader.get('Description', ''),
        'timestamp': datetime.datetime.now().isoformat(),
        'topRecommendation': {
            'ticker': top_recommendation['ticker'],
            'confidence': top_recommendation['score'],
            'quip': quip
        },
        'allRecommendations': recommendations,
        'traderPersona': {
            'type': trader.get('TraderType', 'unknown'),
            'strategy': trader.get('TradingStrategy', 'unknown'),
            'riskProfile': trader.get('RiskTolerance', 'unknown')
        }
    }

    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'  # Enable CORS
        },
        'body': json.dumps(result)
    }


def get_recommendations_for_trader(trader):
    """Generate stock recommendations based on trader's strategy."""
    strategy = trader.get('TradingStrategy', 'passive_index')

    # Define recommendation sets for each trading strategy
    recommendations_by_strategy = {
        "political_insider": [
            {"ticker": "NVDA", "score": 0.94, "sector": "Technology"},
            {"ticker": "MSFT", "score": 0.91, "sector": "Technology"},
            {"ticker": "LMT", "score": 0.87, "sector": "Defense"}
        ],
        "chill_pragmatic": [
            {"ticker": "JNJ", "score": 0.89, "sector": "Healthcare"},
            {"ticker": "PG", "score": 0.87, "sector": "Consumer Staples"},
            {"ticker": "KO", "score": 0.86, "sector": "Consumer Staples"}
        ],
        "political_contrarian": [
            {"ticker": "XOM", "score": 0.88, "sector": "Energy"},
            {"ticker": "DWAC", "score": 0.85, "sector": "Technology"},
            {"ticker": "PLTR", "score": 0.82, "sector": "Technology"}
        ],
        "secretive": [
            {"ticker": "TSLA", "score": 0.95, "sector": "Automotive"},
            {"ticker": "AAPL", "score": 0.93, "sector": "Technology"},
            {"ticker": "AMD", "score": 0.91, "sector": "Technology"}
        ],
        "passive_index": [
            {"ticker": "VTI", "score": 0.99, "sector": "ETF"},
            {"ticker": "SPY", "score": 0.98, "sector": "ETF"},
            {"ticker": "QQQ", "score": 0.86, "sector": "ETF"}
        ]
    }

    # Return recommendations for the trader's strategy, or default to passive_index
    return recommendations_by_strategy.get(strategy, recommendations_by_strategy['passive_index'])


def generate_quip(trader, ticker):
    """Generate a personalized quip for the trader based on their style."""
    strategy = trader.get('TradingStrategy', 'passive_index')

    # Define templates for each trading strategy
    quip_templates = {
        "political_insider": [
            f"My portfolio is like my political career—built on *perfect timing*. I've been eyeing {ticker} for a while, and now might be the *perfect moment* to invest.",
            f"Let me share a little market wisdom: {ticker} is showing some very promising indicators. I just happened to notice them before the general public, as one does.",
            f"I've had my eye on {ticker} for some time now. It's amazing what you can learn when you're deeply involved in... legislative affairs."
        ],
        "chill_pragmatic": [
            f"Look, {ticker} isn't flashy, but it's solid... kinda like my hoodie collection. Steady wins the race, you know?",
            f"I might forget what I said five minutes ago, but I won't forget that {ticker} is a rock-solid pick for the long haul. Keep it chill.",
            f"When you're looking for steady growth without the drama, {ticker} is the way to go. Just set it and... wait, what were we talking about?"
        ],
        "political_contrarian": [
            f"While everyone else is looking left, I'm looking right at {ticker}! This overlooked gem is about to EXPLODE, and I'm not afraid to say it!",
            f"The mainstream analysts won't tell you this, but {ticker} is positioned for a MAJOR breakthrough. Do your own research, patriots!",
            f"{ticker} isn't getting the attention it deserves, and that's EXACTLY why we should be buying it right now! Bold moves win in this market!"
        ],
        "secretive": [
            f"*Soft clucking noises* {ticker} *more mysterious clucking*",
            f"BAWK! {ticker}! BAWK BAWK! *scratches ground mysteriously*",
            f"*Quiet chicken noises* I rarely share my picks, but {ticker} has caught my eye. Don't tell anyone I told you. *nervous wing flapping*"
        ],
        "passive_index": [
            f"Look, I'm not going to pretend {ticker} is exciting. It's an index fund. It's boring. But it works, and that's all that matters.",
            f"Here's my hot tip: {ticker}. It's an index fund. You'll make about 7% annually over 30 years. Not sexy, but it pays for retirement.",
            f"I could pretend I have some special insight, but really, just buy {ticker} and forget about it for a decade. Boring works."
        ]
    }

    # Get templates for this strategy or default to passive_index
    strategy_templates = quip_templates.get(strategy, quip_templates['passive_index'])

    # Select a random template
    return random.choice(strategy_templates)